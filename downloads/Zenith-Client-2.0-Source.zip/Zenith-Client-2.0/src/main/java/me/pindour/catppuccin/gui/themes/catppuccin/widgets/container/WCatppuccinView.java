package me.pindour.catppuccin.gui.themes.catppuccin.widgets.container;

import me.pindour.catppuccin.gui.themes.catppuccin.CatppuccinWidget;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.widgets.containers.WView;
import meteordevelopment.meteorclient.utils.Utils;

//? if <=1.21.10
//import me.pindour.catppuccin.gui.widgets.IWidgetBackport;

public class WCatppuccinView extends WView implements CatppuccinWidget {

    @Override
    public void init() {
        maxHeight = Utils.getWindowHeight() - theme.scale(200);
    }

    @Override
    protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
        if (canScroll && hasScrollBar) {
            roundedRect().pos(handleX(), y)
                         .size(handleWidth(), height)
                         .radius(smallRadius())
                         .color(theme().crustColor())
                         .render();

            roundedRect().pos(handleX(), handleY())
                         .size(handleWidth(), handleHeight())
                         .radius(smallRadius())
                         .outline(theme().crustColor(), 1f)
                         .color(theme().scrollbarColor.get(
                                 //? if >=1.21.11 {
                                 focused,
                                 //? } else
                                 //((IWidgetBackport)this).catppuccin$isSelfFocused(),
                                 handleMouseOver
                         ))
                         .render();
        }
    }
}

package me.pindour.catppuccin.renderer;

import me.pindour.catppuccin.api.render.shape.RoundedRect;
import me.pindour.catppuccin.api.render.RoundedRectRenderer;
import me.pindour.catppuccin.api.render.style.Outline;
import me.pindour.catppuccin.api.render.style.Shadow;
import me.pindour.catppuccin.api.text.RichText;
import me.pindour.catppuccin.gui.themes.catppuccin.CatppuccinGuiTheme;
import me.pindour.catppuccin.renderer.rounded.RoundedRendererInternal;
import me.pindour.catppuccin.renderer.text.CatppuccinTextRenderer;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.utils.render.color.Color;

//? if >=1.21.5 {
import me.pindour.catppuccin.renderer.rounded.modern.RoundedRendererModern;
//?} else {
/*import me.pindour.catppuccin.renderer.rounded.legacy.RoundedRendererLegacy;
import com.mojang.blaze3d.vertex.PoseStack;
*///?}

//? >=26.2
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class CatppuccinRenderer implements RoundedRectRenderer {
    private static final CatppuccinRenderer INSTANCE = new CatppuccinRenderer();
    public static GuiRenderer guiRenderer;

    private CatppuccinGuiTheme theme;

    //? if >=1.21.5
    private final RoundedRendererInternal roundedRenderer = new RoundedRendererModern();
    //? if <=1.21.4
    //private final RoundedRendererInternal roundedRenderer = new RoundedRendererLegacy();

    private final CatppuccinTextRenderer textRenderer = new CatppuccinTextRenderer();

    private boolean clipEnabled = false;
    private float clipMinX;
    private float clipMinY;
    private float clipMaxX;
    private float clipMaxY;

    public static CatppuccinRenderer get() {
        return INSTANCE;
    }

    public void setTheme(CatppuccinGuiTheme theme) {
        this.theme = theme;
    }

    public void begin() {
        roundedRenderer.begin();
    }

    public void end() {
        roundedRenderer.end();
    }

    //? if <=1.21.4 {
    /*public void render(PoseStack matrices) {
        roundedRenderer.render(matrices);
    }
    *///?}

    public void renderText(
            //? if >=26.2
            GuiGraphicsExtractor graphics
    ) {
        if (theme == null) return;

        textRenderer.render(
                //? if >=26.2
                graphics,
                theme
        );
    }

    public void setClipRect(double minX, double minY, double maxX, double maxY) {
        clipEnabled = true;
        clipMinX = (float) minX;
        clipMinY = (float) minY;
        clipMaxX = (float) maxX;
        clipMaxY = (float) maxY;
    }

    public void clearClipRect() {
        clipEnabled = false;
        clipMinX = 0f;
        clipMinY = 0f;
        clipMaxX = 0f;
        clipMaxY = 0f;
    }

    public boolean isClipEnabled() {
        return clipEnabled;
    }

    public float getClipMinX() { return clipMinX; }
    public float getClipMinY() { return clipMinY; }
    public float getClipMaxX() { return clipMaxX; }
    public float getClipMaxY() { return clipMaxY; }

    public void text(RichText text, double x, double y, Color color) {
        if (guiRenderer != null && !Config.get().customFont.get())
            guiRenderer.text(text.getPlainText(), x, y, color, false);

        else textRenderer.text(text, x, y, color, theme);
    }

    /**
     * Low-level render method that renders a rounded rectangle using a shader SDF with selective corner rounding.
     * This method should not be called directly; use {@link RoundedRect} instead.
     *
     * @param x            The X coordinate of the rectangle.
     * @param y            The Y coordinate of the rectangle.
     * @param width        The width of the rectangle.
     * @param height       The height of the rectangle.
     * @param rTopLeft     Top-left corner radius in pixels.
     * @param rTopRight    Top-right corner radius in pixels.
     * @param rBottomLeft  Bottom-left corner radius in pixels.
     * @param rBottomRight Bottom-right corner radius in pixels.
     * @param fillColor    The fill color of the rectangle.
     * @param outline      Rectangle's outline data.
     * @param shadow       Rectangle's shadow data.
     */
    @Override
    public void renderRoundedRect(double x, double y,
                                  double width, double height,
                                  float rTopLeft, float rTopRight,
                                  float rBottomLeft, float rBottomRight,
                                  Color fillColor,
                                  Outline outline,
                                  Shadow shadow
    ) {
        roundedRenderer.render(
                x, y,
                width, height,
                rTopLeft, rTopRight,
                rBottomLeft, rBottomRight,
                fillColor,
                outline,
                shadow
        );
    }

    public void flipFrame() {
        roundedRenderer.flipFrame();
    }
}
